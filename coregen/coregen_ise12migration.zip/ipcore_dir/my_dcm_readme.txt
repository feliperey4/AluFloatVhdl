The following files were generated for 'my_dcm' in directory 
C:\xup\fpgaflow\labs\vhdl\lab5\coregen\ipcore_dir\

my_dcm_readme.txt:
   Text file indicating the files generated and how they are used.

my_dcm_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

my_dcm_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

